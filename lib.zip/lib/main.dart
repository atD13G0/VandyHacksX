import 'dart:async';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:aeyes_3/Screens/TakePictureScreen.dart';

Future<void> main() async {
  // Ensure that plugin services are initialized so that `availableCameras()`
  // can be called before `runApp()`
  WidgetsFlutterBinding.ensureInitialized();

  // Setting the environment variable for Google Cloud Credentials
  Platform.environment['GOOGLE_APPLICATION_CREDENTIALS'] = 'rock-sorter-403218-c8e58de92b0d.json';

  Platform.environment['REPLICATE_API_TOKEN'] = 'your_replicate_api_token_here';


  // Obtain a list of the available cameras on the device.
  final cameras = await availableCameras();

  // Get a specific camera from the list of available cameras.
  final firstCamera = cameras.first;

  runApp(
    MaterialApp(
      theme: ThemeData.dark(),
      home: TakePictureScreen(
        // Pass the appropriate camera to the TakePictureScreen widget.
        camera: firstCamera,
      ),
    ),
  );
}
